// RUN: %llvmgcc %s -S -o -
struct Z { int :0; } z;
