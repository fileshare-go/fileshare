// RUN: %llvmgcc -c -g %s  -o /dev/null

static unsigned char out[]={0,1};
static const unsigned char str1[]="1";

