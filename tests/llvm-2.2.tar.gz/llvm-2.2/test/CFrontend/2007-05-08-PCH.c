// PR 1400
// RUN: %llvmgcc -x c-header %s -o /dev/null

int main() {
  return 0;
}

